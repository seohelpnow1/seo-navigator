import { base44 } from './base44Client';


export const SeoAnalysis = base44.entities.SeoAnalysis;



// auth sdk:
export const User = base44.auth;