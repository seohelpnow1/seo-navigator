import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { InvokeLLM } from "@/api/integrations";
import { Loader2, Rss, Download, CheckCircle, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function RssSubmission() {
  const [rssFeedUrl, setRssFeedUrl] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submitRssFeed = async () => {
    if (!rssFeedUrl.trim()) {
      setError("Please enter an RSS feed URL");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    try {
      const response = await InvokeLLM({
        prompt: `Simulate RSS feed submission to major RSS directories for "${rssFeedUrl}". 
        Provide a list of RSS directories and their submission status (Success/Failed).
        Include popular directories like Google Blog Search, Feedburner, BlogLines, etc.`,
        response_json_schema: {
          type: "object",
          properties: {
            rssFeedUrl: { type: "string" },
            totalDirectories: { type: "number" },
            successfulSubmissions: { type: "number" },
            failedSubmissions: { type: "number" },
            submissions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  directory: { type: "string" },
                  status: { type: "string" },
                  responseTime: { type: "number" },
                  notes: { type: "string" }
                }
              }
            }
          }
        }
      });

      setResults(response);
    } catch (err) {
      setError("Failed to submit RSS feed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const downloadResults = () => {
    if (!results) return;
    
    const csvContent = [
      "Directory,Status,Response Time (ms),Notes",
      ...results.submissions?.map(sub => 
        `"${sub.directory}","${sub.status}",${sub.responseTime},"${sub.notes || ''}"`
      ) || []
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'rss-submission-report.csv';
    a.click();
  };

  const getStatusIcon = (status) => {
    return status?.toLowerCase() === 'success' 
      ? <CheckCircle className="w-5 h-5 text-green-600" />
      : <XCircle className="w-5 h-5 text-red-600" />;
  };

  const getStatusColor = (status) => {
    return status?.toLowerCase() === 'success'
      ? 'bg-green-100 text-green-800'
      : 'bg-red-100 text-red-800';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Rss className="w-8 h-8 text-amber-600" />
            <h1 className="text-3xl font-bold text-slate-900">RSS Feed Submission</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Submit your RSS feed to multiple directories to increase visibility and reach
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-amber-50 to-amber-100 border-b">
            <CardTitle className="flex items-center gap-2 text-amber-900">
              <Rss className="w-5 h-5" />
              RSS Feed Submission
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="rssFeedUrl" className="text-sm font-medium text-slate-700">RSS Feed URL</Label>
                <Input
                  id="rssFeedUrl"
                  type="url"
                  placeholder="https://example.com/feed.xml"
                  value={rssFeedUrl}
                  onChange={(e) => setRssFeedUrl(e.target.value)}
                  className="mt-1"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Enter your complete RSS feed URL including the protocol (http:// or https://)
                </p>
              </div>
              
              {error && (
                <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">
                  {error}
                </div>
              )}

              <Button 
                onClick={submitRssFeed} 
                disabled={loading}
                className="w-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Submitting RSS Feed...
                  </>
                ) : (
                  <>
                    <Rss className="w-4 h-4 mr-2" />
                    Submit RSS Feed
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-blue-900">Submission Summary</CardTitle>
                  <Button variant="outline" onClick={downloadResults} size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download Report
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-blue-700 mb-1">Total Directories</h3>
                    <span className="text-2xl font-bold text-blue-900">{results.totalDirectories}</span>
                  </div>
                  
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-green-700 mb-1">Successful</h3>
                    <span className="text-2xl font-bold text-green-900">{results.successfulSubmissions}</span>
                  </div>
                  
                  <div className="bg-red-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-red-700 mb-1">Failed</h3>
                    <span className="text-2xl font-bold text-red-900">{results.failedSubmissions}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Results */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 border-b">
                <CardTitle className="text-slate-900">Submission Details</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-3">
                  {results.submissions?.map((submission, index) => (
                    <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(submission.status)}
                          <div>
                            <h3 className="font-medium text-slate-900">{submission.directory}</h3>
                            {submission.notes && (
                              <p className="text-sm text-slate-600">{submission.notes}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {submission.responseTime && (
                            <span className="text-sm text-slate-500">
                              {submission.responseTime}ms
                            </span>
                          )}
                          <Badge className={getStatusColor(submission.status)}>
                            {submission.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}