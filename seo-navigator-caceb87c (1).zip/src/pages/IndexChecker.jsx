import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { InvokeLLM } from "@/api/integrations";
import { Loader2, FileSearch, Download, CheckCircle, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function IndexChecker() {
  const [urls, setUrls] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const checkIndexStatus = async () => {
    if (!urls.trim()) {
      setError("Please enter URLs to check");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    const urlList = urls.split('\n').filter(url => url.trim());

    try {
      const response = await InvokeLLM({
        prompt: `Check the Google index status for these URLs: ${urlList.join(', ')}. 
        For each URL, determine if it's indexed by Google and provide the index status.
        Return results with URL and status (Indexed/Not Indexed/Unknown).`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            totalUrls: { type: "number" },
            indexedCount: { type: "number" },
            notIndexedCount: { type: "number" },
            results: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  url: { type: "string" },
                  status: { type: "string" },
                  notes: { type: "string" }
                }
              }
            }
          }
        }
      });

      setResults(response);
    } catch (err) {
      setError("Failed to check index status. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const downloadResults = () => {
    if (!results) return;
    
    const csvContent = [
      "URL,Status,Notes",
      ...results.results.map(result => 
        `"${result.url}","${result.status}","${result.notes || ''}"`
      )
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index-status-report.csv';
    a.click();
  };

  const getStatusIcon = (status) => {
    switch (status?.toLowerCase()) {
      case 'indexed':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'not indexed':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <FileSearch className="w-5 h-5 text-yellow-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'indexed':
        return 'bg-green-100 text-green-800';
      case 'not indexed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <FileSearch className="w-8 h-8 text-indigo-600" />
            <h1 className="text-3xl font-bold text-slate-900">Google Index Checker</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Verify if your web pages are indexed by Google and discover indexation issues
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-indigo-50 to-indigo-100 border-b">
            <CardTitle className="flex items-center gap-2 text-indigo-900">
              <FileSearch className="w-5 h-5" />
              URL Index Status Check
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="urls" className="text-sm font-medium text-slate-700">
                  URLs to Check (one per line)
                </Label>
                <Textarea
                  id="urls"
                  placeholder="https://example.com/page1&#10;https://example.com/page2&#10;https://example.com/page3"
                  value={urls}
                  onChange={(e) => setUrls(e.target.value)}
                  className="mt-1 h-32"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Enter each URL on a separate line. You can check up to 50 URLs at once.
                </p>
              </div>
              
              {error && (
                <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">
                  {error}
                </div>
              )}

              <Button 
                onClick={checkIndexStatus} 
                disabled={loading}
                className="w-full bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Checking Index Status...
                  </>
                ) : (
                  <>
                    <FileSearch className="w-4 h-4 mr-2" />
                    Check Index Status
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-blue-900">Index Status Summary</CardTitle>
                  <Button variant="outline" onClick={downloadResults} size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download Report
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-blue-700 mb-1">Total URLs</h3>
                    <span className="text-2xl font-bold text-blue-900">{results.totalUrls}</span>
                  </div>
                  
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-green-700 mb-1">Indexed</h3>
                    <span className="text-2xl font-bold text-green-900">{results.indexedCount}</span>
                  </div>
                  
                  <div className="bg-red-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-red-700 mb-1">Not Indexed</h3>
                    <span className="text-2xl font-bold text-red-900">{results.notIndexedCount}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Results */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 border-b">
                <CardTitle className="text-slate-900">Detailed Results</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-3">
                  {results.results?.map((result, index) => (
                    <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start gap-4">
                        {getStatusIcon(result.status)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-medium text-slate-900 truncate">
                              {result.url}
                            </h3>
                            <Badge className={getStatusColor(result.status)}>
                              {result.status}
                            </Badge>
                          </div>
                          {result.notes && (
                            <p className="text-sm text-slate-600">{result.notes}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}