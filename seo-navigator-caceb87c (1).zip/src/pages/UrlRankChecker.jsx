import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { InvokeLLM } from "@/api/integrations";
import { Loader2, TrendingUp, Globe, BarChart3, Download } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function UrlRankChecker() {
  const [url, setUrl] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const checkRank = async () => {
    if (!url.trim()) {
      setError("Please enter a URL");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    try {
      const response = await InvokeLLM({
        prompt: `Analyze the domain authority and SEO metrics for this URL: ${url}. 
        Provide domain rating, estimated authority score, and basic SEO assessment.
        Format as JSON with domainRating (0-100), authorityScore (0-100), and assessment text.`,
        response_json_schema: {
          type: "object",
          properties: {
            domainRating: { type: "number" },
            authorityScore: { type: "number" },
            assessment: { type: "string" },
            recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      setResults(response);
    } catch (err) {
      setError("Failed to analyze URL. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const downloadResults = () => {
    if (!results) return;
    
    const csvContent = `Metric,Value
Domain Rating,${results.domainRating}
Authority Score,${results.authorityScore}
Assessment,"${results.assessment}"
Recommendations,"${results.recommendations?.join('; ')}"`;
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'url-rank-analysis.csv';
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <TrendingUp className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-slate-900">URL Rank Checker</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Analyze your website's domain rating and authority metrics to understand your SEO performance
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Globe className="w-5 h-5" />
              Enter URL for Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="url" className="text-sm font-medium text-slate-700">Website URL</Label>
                <Input
                  id="url"
                  type="url"
                  placeholder="https://example.com"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="mt-1"
                />
              </div>
              
              {error && (
                <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">
                  {error}
                </div>
              )}

              <Button 
                onClick={checkRank} 
                disabled={loading}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Check Rank
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {results && (
          <Card className="shadow-xl border-0">
            <CardHeader className="bg-gradient-to-r from-emerald-50 to-emerald-100 border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-emerald-900">Analysis Results</CardTitle>
                <Button variant="outline" onClick={downloadResults} size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Download CSV
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-blue-700 mb-1">Domain Rating</h3>
                  <div className="flex items-center gap-2">
                    <span className="text-3xl font-bold text-blue-900">{results.domainRating}</span>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                      /100
                    </Badge>
                  </div>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-purple-700 mb-1">Authority Score</h3>
                  <div className="flex items-center gap-2">
                    <span className="text-3xl font-bold text-purple-900">{results.authorityScore}</span>
                    <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                      /100
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">Assessment</h3>
                  <p className="text-slate-700 bg-slate-50 p-4 rounded-lg">
                    {results.assessment}
                  </p>
                </div>

                {results.recommendations && results.recommendations.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">Recommendations</h3>
                    <ul className="space-y-2">
                      {results.recommendations.map((rec, index) => (
                        <li key={index} className="flex items-start gap-2 text-slate-700">
                          <span className="w-2 h-2 bg-emerald-500 rounded-full mt-2 flex-shrink-0"></span>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}