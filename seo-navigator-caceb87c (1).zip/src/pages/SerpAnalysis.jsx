import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InvokeLLM } from "@/api/integrations";
import { Loader2, BarChart3, Search, Globe, Download, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function SerpAnalysis() {
  const [keyword, setKeyword] = useState("");
  const [location, setLocation] = useState("us");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const locations = [
    { value: "us", label: "United States" },
    { value: "uk", label: "United Kingdom" },
    { value: "ca", label: "Canada" },
    { value: "au", label: "Australia" },
    { value: "de", label: "Germany" },
    { value: "fr", label: "France" },
    { value: "es", label: "Spain" },
    { value: "it", label: "Italy" },
    { value: "mx", label: "Mexico" },
    { value: "br", label: "Brazil" }
  ];

  const analyzeSERP = async () => {
    if (!keyword.trim()) {
      setError("Please enter a keyword");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    try {
      const response = await InvokeLLM({
        prompt: `Analyze the SERP (Search Engine Results Page) for the keyword "${keyword}" in ${location}. 
        Provide top 10 search results with titles, URLs, meta descriptions, and estimated metrics.
        Include search volume, competition level, and difficulty score.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            keyword: { type: "string" },
            searchVolume: { type: "number" },
            competition: { type: "string" },
            difficulty: { type: "number" },
            results: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  position: { type: "number" },
                  title: { type: "string" },
                  url: { type: "string" },
                  description: { type: "string" },
                  domain: { type: "string" }
                }
              }
            }
          }
        }
      });

      setResults(response);
    } catch (err) {
      setError("Failed to analyze SERP. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const downloadResults = () => {
    if (!results) return;
    
    const csvContent = [
      "Position,Title,URL,Domain,Description",
      ...results.results.map(result => 
        `${result.position},"${result.title}","${result.url}","${result.domain}","${result.description}"`
      )
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `serp-analysis-${keyword}.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <BarChart3 className="w-8 h-8 text-orange-600" />
            <h1 className="text-3xl font-bold text-slate-900">SERP Analysis</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Analyze search engine results pages to understand competition and ranking opportunities
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 border-b">
            <CardTitle className="flex items-center gap-2 text-orange-900">
              <Search className="w-5 h-5" />
              SERP Analysis Parameters
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <Label htmlFor="keyword" className="text-sm font-medium text-slate-700">Target Keyword</Label>
                <Input
                  id="keyword"
                  placeholder="Enter keyword to analyze"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label htmlFor="location" className="text-sm font-medium text-slate-700">Location</Label>
                <Select value={location} onValueChange={setLocation}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map((loc) => (
                      <SelectItem key={loc.value} value={loc.value}>
                        {loc.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {error && (
              <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg mb-4">
                {error}
              </div>
            )}

            <Button 
              onClick={analyzeSERP} 
              disabled={loading}
              className="w-full bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing SERP...
                </>
              ) : (
                <>
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Analyze SERP
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {results && (
          <div className="space-y-6">
            {/* Keyword Overview */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-blue-900">Keyword Overview</CardTitle>
                  <Button variant="outline" onClick={downloadResults} size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download Results
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-blue-700 mb-1">Search Volume</h3>
                    <span className="text-2xl font-bold text-blue-900">
                      {results.searchVolume?.toLocaleString() || 'N/A'}
                    </span>
                  </div>
                  
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-purple-700 mb-1">Competition</h3>
                    <Badge className={`${
                      results.competition === 'High' ? 'bg-red-100 text-red-800' :
                      results.competition === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {results.competition || 'N/A'}
                    </Badge>
                  </div>
                  
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-orange-700 mb-1">Difficulty Score</h3>
                    <span className="text-2xl font-bold text-orange-900">
                      {results.difficulty || 'N/A'}/100
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* SERP Results */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-emerald-50 to-emerald-100 border-b">
                <CardTitle className="text-emerald-900">Top Search Results</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {results.results?.slice(0, 10).map((result, index) => (
                    <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start gap-4">
                        <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {result.position || index + 1}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-slate-900 mb-1">
                            {result.title}
                          </h3>
                          <div className="flex items-center gap-2 mb-2">
                            <Globe className="w-4 h-4 text-slate-400" />
                            <span className="text-sm text-emerald-600">{result.domain}</span>
                            <a 
                              href={result.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-slate-400 hover:text-slate-600"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          </div>
                          <p className="text-sm text-slate-600">
                            {result.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}