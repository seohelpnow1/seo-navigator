import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { InvokeLLM } from "@/api/integrations";
import { Loader2, MessageSquare, Download, BarChart3 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function EngagementReport() {
  const [articles, setArticles] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const analyzeEngagement = async () => {
    if (!articles.trim()) {
      setError("Please enter articles to analyze");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    try {
      const response = await InvokeLLM({
        prompt: `Analyze the engagement level of these articles. Look for calls-to-action, 
        engagement triggers, emotional hooks, and reader interaction elements.
        Provide engagement scores (0-100) and specific recommendations.
        
        Articles: "${articles}"`,
        response_json_schema: {
          type: "object",
          properties: {
            overallEngagementScore: { type: "number" },
            totalArticles: { type: "number" },
            averageScore: { type: "number" },
            articleAnalysis: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  engagementScore: { type: "number" },
                  callsToAction: { type: "number" },
                  emotionalHooks: { type: "number" },
                  readabilityScore: { type: "number" },
                  recommendations: { type: "array", items: { type: "string" } }
                }
              }
            },
            globalRecommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      setResults(response);
    } catch (err) {
      setError("Failed to analyze engagement. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const downloadResults = () => {
    if (!results) return;
    
    const csvContent = [
      "Article Title,Engagement Score,Calls to Action,Emotional Hooks,Readability Score",
      ...results.articleAnalysis?.map(article => 
        `"${article.title}",${article.engagementScore},${article.callsToAction},${article.emotionalHooks},${article.readabilityScore}`
      ) || []
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'engagement-analysis-report.csv';
    a.click();
  };

  const getEngagementColor = (score) => {
    if (score >= 80) return 'text-green-600 bg-green-50';
    if (score >= 60) return 'text-blue-600 bg-blue-50';
    if (score >= 40) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const getEngagementLevel = (score) => {
    if (score >= 80) return { text: 'Excellent', color: 'bg-green-100 text-green-800' };
    if (score >= 60) return { text: 'Good', color: 'bg-blue-100 text-blue-800' };
    if (score >= 40) return { text: 'Fair', color: 'bg-yellow-100 text-yellow-800' };
    return { text: 'Poor', color: 'bg-red-100 text-red-800' };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <MessageSquare className="w-8 h-8 text-rose-600" />
            <h1 className="text-3xl font-bold text-slate-900">Engagement Report</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Analyze your content's engagement potential and discover optimization opportunities
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-rose-50 to-rose-100 border-b">
            <CardTitle className="flex items-center gap-2 text-rose-900">
              <MessageSquare className="w-5 h-5" />
              Content Engagement Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="articles" className="text-sm font-medium text-slate-700">
                  Articles to Analyze (separate each article with two line breaks)
                </Label>
                <Textarea
                  id="articles"
                  placeholder="Article Title 1&#10;Article content goes here...&#10;&#10;Article Title 2&#10;More article content..."
                  value={articles}
                  onChange={(e) => setArticles(e.target.value)}
                  className="mt-1 h-48"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Paste your complete articles including titles. An engagement score above 30 indicates highly engaging content.
                </p>
              </div>
              
              {error && (
                <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">
                  {error}
                </div>
              )}

              <Button 
                onClick={analyzeEngagement} 
                disabled={loading}
                className="w-full bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing Engagement...
                  </>
                ) : (
                  <>
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Generate Engagement Report
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {results && (
          <div className="space-y-6">
            {/* Overview */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-blue-900">Engagement Overview</CardTitle>
                  <Button variant="outline" onClick={downloadResults} size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download Report
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className={`p-4 rounded-lg ${getEngagementColor(results.overallEngagementScore)}`}>
                    <h3 className="text-sm font-medium mb-1">Overall Score</h3>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold">{results.overallEngagementScore}</span>
                      <Badge className={getEngagementLevel(results.overallEngagementScore).color}>
                        {getEngagementLevel(results.overallEngagementScore).text}
                      </Badge>
                    </div>
                    <Progress value={results.overallEngagementScore} className="mt-2" />
                  </div>
                  
                  <div className="bg-emerald-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-emerald-700 mb-1">Articles Analyzed</h3>
                    <span className="text-2xl font-bold text-emerald-900">{results.totalArticles}</span>
                  </div>
                  
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-purple-700 mb-1">Average Score</h3>
                    <span className="text-2xl font-bold text-purple-900">{results.averageScore}</span>
                  </div>
                </div>

                {/* Global Recommendations */}
                {results.globalRecommendations && results.globalRecommendations.length > 0 && (
                  <div className="mt-6 bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <h3 className="font-semibold text-amber-900 mb-2">Global Recommendations</h3>
                    <ul className="space-y-1">
                      {results.globalRecommendations.map((rec, index) => (
                        <li key={index} className="flex items-start gap-2 text-amber-800">
                          <span className="w-2 h-2 bg-amber-500 rounded-full mt-2 flex-shrink-0"></span>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Individual Article Analysis */}
            {results.articleAnalysis && results.articleAnalysis.length > 0 && (
              <Card className="shadow-xl border-0">
                <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 border-b">
                  <CardTitle className="text-slate-900">Individual Article Analysis</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    {results.articleAnalysis.map((article, index) => (
                      <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between mb-4">
                          <h3 className="font-semibold text-slate-900 text-lg">{article.title}</h3>
                          <Badge className={getEngagementLevel(article.engagementScore).color}>
                            {article.engagementScore}/100
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                          <div className="text-center">
                            <p className="text-xs text-slate-500 mb-1">Calls to Action</p>
                            <p className="text-lg font-bold text-blue-600">{article.callsToAction}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-xs text-slate-500 mb-1">Emotional Hooks</p>
                            <p className="text-lg font-bold text-purple-600">{article.emotionalHooks}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-xs text-slate-500 mb-1">Readability</p>
                            <p className="text-lg font-bold text-emerald-600">{article.readabilityScore}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-xs text-slate-500 mb-1">Engagement</p>
                            <p className="text-lg font-bold text-rose-600">{article.engagementScore}</p>
                          </div>
                        </div>

                        {article.recommendations && article.recommendations.length > 0 && (
                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                            <h4 className="font-medium text-blue-900 mb-2">Recommendations</h4>
                            <ul className="space-y-1">
                              {article.recommendations.map((rec, recIndex) => (
                                <li key={recIndex} className="flex items-start gap-2 text-blue-800 text-sm">
                                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 flex-shrink-0"></span>
                                  {rec}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}