import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Search, 
  BarChart3, 
  Globe, 
  TrendingUp, 
  FileSearch, 
  Target, 
  MessageSquare, 
  Rss,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const tools = [
  {
    title: "URL Rank Checker",
    description: "Check your website's domain rating and Ahrefs rank metrics",
    icon: TrendingUp,
    url: createPageUrl("UrlRankChecker"),
    color: "from-blue-500 to-blue-600",
    bgColor: "bg-blue-50",
    textColor: "text-blue-700"
  },
  {
    title: "Keyword Difficulty",
    description: "Analyze keyword competition and ranking difficulty",
    icon: Target,
    url: createPageUrl("KeywordDifficulty"),
    color: "from-purple-500 to-purple-600",
    bgColor: "bg-purple-50",
    textColor: "text-purple-700"
  },
  {
    title: "Keyword Research",
    description: "Discover profitable keywords with search volume data",
    icon: Search,
    url: createPageUrl("KeywordResearch"),
    color: "from-emerald-500 to-emerald-600",
    bgColor: "bg-emerald-50",
    textColor: "text-emerald-700"
  },
  {
    title: "SERP Analysis",
    description: "Analyze search engine results for any keyword",
    icon: BarChart3,
    url: createPageUrl("SerpAnalysis"),
    color: "from-orange-500 to-orange-600",
    bgColor: "bg-orange-50",
    textColor: "text-orange-700"
  },
  {
    title: "Domain Metrics",
    description: "Get comprehensive domain authority and trust metrics",
    icon: Globe,
    url: createPageUrl("DomainMetrics"),
    color: "from-cyan-500 to-cyan-600",
    bgColor: "bg-cyan-50",
    textColor: "text-cyan-700"
  },
  {
    title: "Index Checker",
    description: "Verify if your URLs are indexed by Google",
    icon: FileSearch,
    url: createPageUrl("IndexChecker"),
    color: "from-indigo-500 to-indigo-600",
    bgColor: "bg-indigo-50",
    textColor: "text-indigo-700"
  },
  {
    title: "Keyword Density",
    description: "Analyze keyword density in your content",
    icon: Target,
    url: createPageUrl("KeywordDensity"),
    color: "from-pink-500 to-pink-600",
    bgColor: "bg-pink-50",
    textColor: "text-pink-700"
  },
  {
    title: "Engagement Report",
    description: "Evaluate content engagement and call-to-action effectiveness",
    icon: MessageSquare,
    url: createPageUrl("EngagementReport"),
    color: "from-rose-500 to-rose-600",
    bgColor: "bg-rose-50",
    textColor: "text-rose-700"
  },
  {
    title: "RSS Submission",
    description: "Submit your RSS feed to multiple directories",
    icon: Rss,
    url: createPageUrl("RssSubmission"),
    color: "from-amber-500 to-amber-600",
    bgColor: "bg-amber-50",
    textColor: "text-amber-700"
  }
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-blue-600" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
              SEO Tool Station
            </h1>
            <Sparkles className="w-8 h-8 text-blue-600" />
          </div>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
            Professional-grade SEO tools to analyze, optimize, and boost your website's search engine performance
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm font-medium">Total Tools</p>
                  <p className="text-3xl font-bold">9</p>
                </div>
                <Search className="w-12 h-12 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-sm font-medium">Categories</p>
                  <p className="text-3xl font-bold">5</p>
                </div>
                <BarChart3 className="w-12 h-12 text-emerald-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm font-medium">Free Access</p>
                  <p className="text-3xl font-bold">100%</p>
                </div>
                <Globe className="w-12 h-12 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map((tool, index) => (
            <Card key={tool.title} className="hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border-0 shadow-lg overflow-hidden group">
              <CardHeader className={`${tool.bgColor} pb-4`}>
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${tool.color} rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <tool.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className={`text-lg font-bold ${tool.textColor}`}>
                      {tool.title}
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6 bg-white">
                <p className="text-slate-600 mb-6 leading-relaxed">
                  {tool.description}
                </p>
                <Link to={tool.url}>
                  <Button className={`w-full bg-gradient-to-r ${tool.color} hover:shadow-lg transition-all duration-300 group`}>
                    Launch Tool
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Footer */}
        <div className="text-center mt-16 pt-8 border-t border-slate-200">
          <p className="text-slate-500">
            © 2024 SEO Tool Station. Professional SEO analysis tools for digital marketers.
          </p>
        </div>
      </div>
    </div>
  );
}