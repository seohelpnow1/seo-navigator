import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { InvokeLLM } from "@/api/integrations";
import { Loader2, Target, Download, BarChart3 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function KeywordDensity() {
  const [keyword, setKeyword] = useState("");
  const [content, setContent] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const analyzeKeywordDensity = async () => {
    if (!keyword.trim() || !content.trim()) {
      setError("Please enter both keyword and content");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    try {
      const response = await InvokeLLM({
        prompt: `Analyze keyword density for the keyword "${keyword}" in the provided content. 
        Calculate keyword density percentage, word count, keyword frequency, and provide recommendations.
        Also analyze related keywords and their densities.
        
        Content: "${content}"`,
        response_json_schema: {
          type: "object",
          properties: {
            targetKeyword: { type: "string" },
            keywordDensity: { type: "number" },
            keywordCount: { type: "number" },
            totalWords: { type: "number" },
            densityStatus: { type: "string" },
            recommendations: { type: "array", items: { type: "string" } },
            relatedKeywords: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  keyword: { type: "string" },
                  count: { type: "number" },
                  density: { type: "number" }
                }
              }
            }
          }
        }
      });

      setResults(response);
    } catch (err) {
      setError("Failed to analyze keyword density. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const downloadResults = () => {
    if (!results) return;
    
    const csvContent = [
      "Metric,Value",
      `Target Keyword,${results.targetKeyword}`,
      `Keyword Density,${results.keywordDensity}%`,
      `Keyword Count,${results.keywordCount}`,
      `Total Words,${results.totalWords}`,
      `Status,${results.densityStatus}`,
      "",
      "Related Keywords,Count,Density",
      ...results.relatedKeywords?.map(kw => 
        `${kw.keyword},${kw.count},${kw.density}%`
      ) || []
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `keyword-density-${keyword}.csv`;
    a.click();
  };

  const getDensityColor = (density) => {
    if (density >= 1 && density <= 3) return 'text-green-600 bg-green-50';
    if (density < 1) return 'text-blue-600 bg-blue-50';
    return 'text-red-600 bg-red-50';
  };

  const getDensityStatus = (density) => {
    if (density >= 1 && density <= 3) return { text: 'Optimal', color: 'bg-green-100 text-green-800' };
    if (density < 1) return { text: 'Too Low', color: 'bg-blue-100 text-blue-800' };
    return { text: 'Too High', color: 'bg-red-100 text-red-800' };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Target className="w-8 h-8 text-pink-600" />
            <h1 className="text-3xl font-bold text-slate-900">Keyword Density Analyzer</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Analyze keyword density in your content to optimize for search engines without keyword stuffing
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-pink-50 to-pink-100 border-b">
            <CardTitle className="flex items-center gap-2 text-pink-900">
              <Target className="w-5 h-5" />
              Content Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="keyword" className="text-sm font-medium text-slate-700">Target Keyword</Label>
                <Input
                  id="keyword"
                  placeholder="Enter your target keyword"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label htmlFor="content" className="text-sm font-medium text-slate-700">Content to Analyze</Label>
                <Textarea
                  id="content"
                  placeholder="Paste your article content here..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="mt-1 h-40"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Ideal keyword density is between 1-3%. Paste your full article content for accurate analysis.
                </p>
              </div>
              
              {error && (
                <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">
                  {error}
                </div>
              )}

              <Button 
                onClick={analyzeKeywordDensity} 
                disabled={loading}
                className="w-full bg-gradient-to-r from-pink-600 to-pink-700 hover:from-pink-700 hover:to-pink-800"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing Density...
                  </>
                ) : (
                  <>
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Analyze Keyword Density
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {results && (
          <div className="space-y-6">
            {/* Main Results */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-blue-900">Density Analysis Results</CardTitle>
                  <Button variant="outline" onClick={downloadResults} size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download Report
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className={`p-4 rounded-lg ${getDensityColor(results.keywordDensity)}`}>
                    <h3 className="text-sm font-medium mb-1">Keyword Density</h3>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold">{results.keywordDensity}%</span>
                      <Badge className={getDensityStatus(results.keywordDensity).color}>
                        {getDensityStatus(results.keywordDensity).text}
                      </Badge>
                    </div>
                    <Progress value={Math.min(results.keywordDensity, 10) * 10} className="mt-2" />
                  </div>
                  
                  <div className="bg-emerald-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-emerald-700 mb-1">Keyword Count</h3>
                    <span className="text-2xl font-bold text-emerald-900">{results.keywordCount}</span>
                  </div>
                  
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-blue-700 mb-1">Total Words</h3>
                    <span className="text-2xl font-bold text-blue-900">
                      {results.totalWords?.toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-purple-700 mb-1">Target Keyword</h3>
                    <span className="text-lg font-semibold text-purple-900 break-words">
                      {results.targetKeyword}
                    </span>
                  </div>
                </div>

                {/* Recommendations */}
                {results.recommendations && results.recommendations.length > 0 && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <h3 className="font-semibold text-amber-900 mb-2">Recommendations</h3>
                    <ul className="space-y-1">
                      {results.recommendations.map((rec, index) => (
                        <li key={index} className="flex items-start gap-2 text-amber-800">
                          <span className="w-2 h-2 bg-amber-500 rounded-full mt-2 flex-shrink-0"></span>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Related Keywords */}
            {results.relatedKeywords && results.relatedKeywords.length > 0 && (
              <Card className="shadow-xl border-0">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-purple-100 border-b">
                  <CardTitle className="text-purple-900">Related Keywords Analysis</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-3 font-semibold text-slate-900">Keyword</th>
                          <th className="text-left p-3 font-semibold text-slate-900">Count</th>
                          <th className="text-left p-3 font-semibold text-slate-900">Density</th>
                          <th className="text-left p-3 font-semibold text-slate-900">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.relatedKeywords.map((kw, index) => (
                          <tr key={index} className="border-b hover:bg-slate-50">
                            <td className="p-3">
                              <span className="font-medium text-slate-900">{kw.keyword}</span>
                            </td>
                            <td className="p-3">
                              <span className="text-slate-700">{kw.count}</span>
                            </td>
                            <td className="p-3">
                              <span className="font-semibold text-purple-600">{kw.density}%</span>
                            </td>
                            <td className="p-3">
                              <Badge className={getDensityStatus(kw.density).color}>
                                {getDensityStatus(kw.density).text}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}