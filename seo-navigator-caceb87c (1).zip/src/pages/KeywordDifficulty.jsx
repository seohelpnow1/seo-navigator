import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InvokeLLM } from "@/api/integrations";
import { Loader2, Target, TrendingUp, Download } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function KeywordDifficulty() {
  const [keyword, setKeyword] = useState("");
  const [country, setCountry] = useState("us");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const countries = [
    { value: "us", label: "United States" },
    { value: "uk", label: "United Kingdom" },
    { value: "ca", label: "Canada" },
    { value: "mx", label: "Mexico" },
    { value: "de", label: "Germany" },
  ];

  const checkDifficulty = async () => {
    if (!keyword.trim()) {
      setError("Please enter a keyword");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    try {
      const response = await InvokeLLM({
        prompt: `Analyze the keyword difficulty for "${keyword}" in ${country}. 
        Provide difficulty score (0-100), competition level, search volume estimate, 
        and top 5 competing websites with their domain metrics.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            keyword: { type: "string" },
            difficulty: { type: "number" },
            competition: { type: "string" },
            searchVolume: { type: "number" },
            cpc: { type: "number" },
            topCompetitors: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  domain: { type: "string" },
                  title: { type: "string" },
                  domainRating: { type: "number" },
                  urlRating: { type: "number" }
                }
              }
            }
          }
        }
      });

      setResults(response);
    } catch (err) {
      setError("Failed to analyze keyword difficulty. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getDifficultyColor = (difficulty) => {
    if (difficulty <= 30) return "text-green-600 bg-green-50";
    if (difficulty <= 60) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  const getDifficultyLabel = (difficulty) => {
    if (difficulty <= 30) return "Easy";
    if (difficulty <= 60) return "Medium";
    return "Hard";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Target className="w-8 h-8 text-purple-600" />
            <h1 className="text-3xl font-bold text-slate-900">Keyword Difficulty Checker</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Analyze keyword competition and discover ranking opportunities with comprehensive difficulty analysis
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-purple-100 border-b">
            <CardTitle className="flex items-center gap-2 text-purple-900">
              <Target className="w-5 h-5" />
              Difficulty Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <Label htmlFor="keyword" className="text-sm font-medium text-slate-700">Keyword</Label>
                <Input
                  id="keyword"
                  placeholder="Enter target keyword"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label htmlFor="country" className="text-sm font-medium text-slate-700">Country</Label>
                <Select value={country} onValueChange={setCountry}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {countries.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        {c.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {error && (
              <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg mb-4">
                {error}
              </div>
            )}

            <Button 
              onClick={checkDifficulty} 
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing Difficulty...
                </>
              ) : (
                <>
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Check Difficulty
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {results && (
          <div className="space-y-6">
            {/* Keyword Metrics */}
            <Card className="shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
                <CardTitle className="text-blue-900">Keyword Metrics</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className={`p-4 rounded-lg ${getDifficultyColor(results.difficulty)}`}>
                    <h3 className="text-sm font-medium mb-1">Difficulty Score</h3>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold">{results.difficulty}</span>
                      <Badge variant="secondary">
                        {getDifficultyLabel(results.difficulty)}
                      </Badge>
                    </div>
                    <Progress value={results.difficulty} className="mt-2" />
                  </div>
                  
                  <div className="bg-emerald-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-emerald-700 mb-1">Search Volume</h3>
                    <span className="text-2xl font-bold text-emerald-900">
                      {results.searchVolume?.toLocaleString() || 'N/A'}
                    </span>
                  </div>
                  
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-orange-700 mb-1">CPC</h3>
                    <span className="text-2xl font-bold text-orange-900">
                      ${results.cpc?.toFixed(2) || '0.00'}
                    </span>
                  </div>
                  
                  <div className="bg-cyan-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-cyan-700 mb-1">Competition</h3>
                    <Badge className={`${
                      results.competition === 'High' ? 'bg-red-100 text-red-800' :
                      results.competition === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {results.competition || 'N/A'}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Top Competitors */}
            {results.topCompetitors && results.topCompetitors.length > 0 && (
              <Card className="shadow-xl border-0">
                <CardHeader className="bg-gradient-to-r from-red-50 to-red-100 border-b">
                  <CardTitle className="text-red-900">Top Competitors</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {results.topCompetitors.map((competitor, index) => (
                      <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold text-slate-900">{competitor.title}</h3>
                            <p className="text-sm text-slate-600">{competitor.domain}</p>
                          </div>
                          <div className="flex gap-4">
                            <div className="text-center">
                              <p className="text-xs text-slate-500">Domain Rating</p>
                              <p className="font-bold text-blue-600">{competitor.domainRating || 'N/A'}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-slate-500">URL Rating</p>
                              <p className="font-bold text-purple-600">{competitor.urlRating || 'N/A'}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}