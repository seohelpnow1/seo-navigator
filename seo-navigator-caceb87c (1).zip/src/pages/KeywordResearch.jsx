import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InvokeLLM } from "@/api/integrations";
import { Loader2, Search, Download, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function KeywordResearch() {
  const [seedKeyword, setSeedKeyword] = useState("");
  const [country, setCountry] = useState("US");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const countries = [
    { value: "US", label: "United States" },
    { value: "UK", label: "United Kingdom" },
    { value: "CA", label: "Canada" },
    { value: "MX", label: "Mexico" },
    { value: "DE", label: "Germany" },
  ];

  const researchKeywords = async () => {
    if (!seedKeyword.trim()) {
      setError("Please enter a seed keyword");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);

    try {
      const response = await InvokeLLM({
        prompt: `Generate comprehensive keyword research for "${seedKeyword}" in ${country}. 
        Provide 20 related keywords with search volume, CPC, competition level, and keyword difficulty scores.
        Include long-tail variations and question-based keywords.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            seedKeyword: { type: "string" },
            totalKeywords: { type: "number" },
            keywords: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  keyword: { type: "string" },
                  searchVolume: { type: "number" },
                  cpc: { type: "number" },
                  competition: { type: "string" },
                  difficulty: { type: "number" },
                  intent: { type: "string" }
                }
              }
            }
          }
        }
      });

      setResults(response);
    } catch (err) {
      setError("Failed to research keywords. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const downloadResults = () => {
    if (!results) return;
    
    const csvContent = [
      "Keyword,Search Volume,CPC,Competition,Difficulty,Intent",
      ...results.keywords.map(kw => 
        `"${kw.keyword}",${kw.searchVolume},$${kw.cpc},${kw.competition},${kw.difficulty},${kw.intent}`
      )
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `keyword-research-${seedKeyword}.csv`;
    a.click();
  };

  const getCompetitionColor = (competition) => {
    switch (competition?.toLowerCase()) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getIntentColor = (intent) => {
    switch (intent?.toLowerCase()) {
      case 'informational': return 'bg-blue-100 text-blue-800';
      case 'commercial': return 'bg-purple-100 text-purple-800';
      case 'transactional': return 'bg-emerald-100 text-emerald-800';
      case 'navigational': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Search className="w-8 h-8 text-emerald-600" />
            <h1 className="text-3xl font-bold text-slate-900">Keyword Research</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Discover profitable keywords and uncover new content opportunities with comprehensive keyword analysis
          </p>
        </div>

        <Card className="shadow-xl border-0 mb-8">
          <CardHeader className="bg-gradient-to-r from-emerald-50 to-emerald-100 border-b">
            <CardTitle className="flex items-center gap-2 text-emerald-900">
              <Search className="w-5 h-5" />
              Keyword Research Parameters
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <Label htmlFor="seedKeyword" className="text-sm font-medium text-slate-700">Seed Keyword</Label>
                <Input
                  id="seedKeyword"
                  placeholder="Enter your main keyword"
                  value={seedKeyword}
                  onChange={(e) => setSeedKeyword(e.target.value)}
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label htmlFor="country" className="text-sm font-medium text-slate-700">Country</Label>
                <Select value={country} onValueChange={setCountry}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {countries.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        {c.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {error && (
              <div className="text-red-600 text-sm bg-red-50 p-3 rounded-lg mb-4">
                {error}
              </div>
            )}

            <Button 
              onClick={researchKeywords} 
              disabled={loading}
              className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Researching Keywords...
                </>
              ) : (
                <>
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Research Keywords
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {results && (
          <Card className="shadow-xl border-0">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-blue-900">Keyword Research Results</CardTitle>
                <Button variant="outline" onClick={downloadResults} size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Download CSV
                </Button>
              </div>
              <p className="text-sm text-blue-700 mt-2">
                Found {results.totalKeywords || results.keywords?.length || 0} keywords for "{results.seedKeyword}"
              </p>
            </CardHeader>
            <CardContent className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-semibold text-slate-900">Keyword</th>
                      <th className="text-left p-3 font-semibold text-slate-900">Volume</th>
                      <th className="text-left p-3 font-semibold text-slate-900">CPC</th>
                      <th className="text-left p-3 font-semibold text-slate-900">Competition</th>
                      <th className="text-left p-3 font-semibold text-slate-900">Difficulty</th>
                      <th className="text-left p-3 font-semibold text-slate-900">Intent</th>
                    </tr>
                  </thead>
                  <tbody>
                    {results.keywords?.map((kw, index) => (
                      <tr key={index} className="border-b hover:bg-slate-50">
                        <td className="p-3">
                          <span className="font-medium text-slate-900">{kw.keyword}</span>
                        </td>
                        <td className="p-3">
                          <span className="text-slate-700">
                            {kw.searchVolume?.toLocaleString() || 'N/A'}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="text-slate-700">
                            ${kw.cpc?.toFixed(2) || '0.00'}
                          </span>
                        </td>
                        <td className="p-3">
                          <Badge className={getCompetitionColor(kw.competition)}>
                            {kw.competition}
                          </Badge>
                        </td>
                        <td className="p-3">
                          <span className={`font-semibold ${
                            kw.difficulty <= 30 ? 'text-green-600' :
                            kw.difficulty <= 60 ? 'text-yellow-600' :
                            'text-red-600'
                          }`}>
                            {kw.difficulty || 'N/A'}
                          </span>
                        </td>
                        <td className="p-3">
                          <Badge className={getIntentColor(kw.intent)}>
                            {kw.intent}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}