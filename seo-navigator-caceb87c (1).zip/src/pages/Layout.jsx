
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Search, 
  BarChart3, 
  Globe, 
  TrendingUp, 
  FileSearch, 
  Target, 
  MessageSquare, 
  Rss,
  Home,
  Menu,
  X
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: Home,
  },
  {
    title: "URL Rank Checker",
    url: createPageUrl("UrlRankChecker"),
    icon: TrendingUp,
  },
  {
    title: "Keyword Difficulty",
    url: createPageUrl("KeywordDifficulty"),
    icon: Target,
  },
  {
    title: "Keyword Research",
    url: createPageUrl("KeywordResearch"),
    icon: Search,
  },
  {
    title: "SERP Analysis",
    url: createPageUrl("SerpAnalysis"),
    icon: BarChart3,
  },
  {
    title: "Domain Metrics",
    url: createPageUrl("DomainMetrics"),
    icon: Globe,
  },
  {
    title: "Index Checker",
    url: createPageUrl("IndexChecker"),
    icon: FileSearch,
  },
  {
    title: "Keyword Density",
    url: createPageUrl("KeywordDensity"),
    icon: Target,
  },
  {
    title: "Engagement Report",
    url: createPageUrl("EngagementReport"),
    icon: MessageSquare,
  },
  {
    title: "RSS Submission",
    url: createPageUrl("RssSubmission"),
    icon: Rss,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <Sidebar className="border-r border-slate-200 bg-slate-50">
          <SidebarHeader className="border-b border-slate-200 p-6 bg-gradient-to-r from-slate-900 to-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                <Search className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-white text-lg">SEO Station</h2>
                <p className="text-xs text-slate-300">Professional SEO Tools</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2 mb-2">
                SEO Tools
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-lg px-3 py-2.5 ${
                          location.pathname === item.url 
                            ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-500 shadow-sm' 
                            : 'text-slate-600 hover:shadow-sm'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium text-sm">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-200 p-4 bg-slate-50">
            <div className="flex items-center gap-3 p-3 rounded-lg bg-white shadow-sm">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-emerald-500 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-sm">U</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-slate-900 text-sm truncate">SEO Expert</p>
                <p className="text-xs text-slate-500 truncate">Optimize your presence</p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col bg-slate-50">
          <header className="bg-white border-b border-slate-200 px-6 py-4 md:hidden shadow-sm">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-bold text-slate-900">SEO Station</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
